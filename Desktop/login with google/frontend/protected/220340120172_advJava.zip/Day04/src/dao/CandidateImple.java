package dao;

import static utils.DBUtils.openConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.Candidate;

public class CandidateImple implements ICandidateDao {
	// state
	private Connection cn;
	private PreparedStatement pst1 ,pst2;

	public CandidateImple() throws SQLException {
		// open cn
		cn = openConnection();
		pst1 = cn.prepareStatement("select * from candidates");
		pst2=cn.prepareStatement("select id,name,party votes+1 from candidates where name=?");
		System.out.println("Candidate dao created");
	}

	@Override
	public Candidate getCandidateDetails() throws SQLException {
		
		try (ResultSet rst = pst1.executeQuery()) {
			// empId, String name, String address, double salary, String deptId, Date
			// joinDate
			while (rst.next()) {
				System.out.printf("Id: %d , Name: %s , Party :%s , Votes :%d  \n",rst.getInt(1), rst.getString(2), rst.getString(3), rst.getInt(4));

			}
		
		}
		return null;
	}

	@Override
	public Candidate IncrementVotes(String name) throws SQLException {
		pst2.setString(1,name);
		
	
		try (ResultSet rst = pst2.executeQuery()) {
			// empId, String name, String address, double salary, String deptId, Date
			// joinDate
			while (rst.next()) {
				System.out.printf("Id: %d , Name: %s , Party :%s , Votes :%d  \n",rst.getInt(1), rst.getString(2), rst.getString(3), rst.getInt(4));
		
			}
		
			}
		return null;

}
}
