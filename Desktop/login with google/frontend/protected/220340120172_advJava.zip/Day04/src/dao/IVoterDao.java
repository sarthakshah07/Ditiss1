package dao;

import java.sql.SQLException;

import pojos.Voters;

public interface IVoterDao {
	Voters authenticateUser(String name ,String password) throws SQLException;
	Voters updateStatus(String name)throws SQLException;

}
