package dao;

import static utils.DBUtils.openConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.Voters;

public class VotersDaoImpl implements IVoterDao {
	private Connection cn;
	private PreparedStatement pst1;
	private PreparedStatement pst2;

	public VotersDaoImpl() throws SQLException {

		cn = openConnection();

		pst1 = cn.prepareStatement("select * from voters where name=? and password= ?");
		pst2=cn.prepareStatement("update voters set status=1 where name=?");
		System.out.println("emp dao created...");
	}

	@Override
	public Voters authenticateUser(String name, String password) throws SQLException {

		pst1.setString(1, name);
		pst1.setString(2, password);
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next()) {
				System.out.println("Logged in succesfully");
			}

		}

		return null;

	}

	@Override
	public Voters updateStatus(String name) throws SQLException {
		pst2.setString(1, name);
		 pst2.executeUpdate();
			
				System.out.println("Status updated Succesfully");
			
			

		
		
		
		return null;
	}

}
