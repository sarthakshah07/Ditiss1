package dao;

import java.sql.SQLException;

import pojos.Candidate;

public interface ICandidateDao {
	public Candidate getCandidateDetails()throws SQLException;
	public Candidate IncrementVotes(String name) throws SQLException;

}
