package tester;

import java.sql.SQLException;
import java.util.Scanner;

import dao.VotersDaoImpl;

public class TestUpdatreStatus {

	public static void main(String[] args) throws SQLException {
		try (Scanner sc = new Scanner(System.in)) {
			VotersDaoImpl voter=new VotersDaoImpl();
			System.out.println("enter user details name");
			voter.updateStatus(sc.next());
		}

	}

	


}
