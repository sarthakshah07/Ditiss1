package tester;

import java.sql.SQLException;
import java.util.Scanner;

import dao.VotersDaoImpl;

public class TestUsersAthentica {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		try (Scanner sc = new Scanner(System.in)) {
			VotersDaoImpl voter=new VotersDaoImpl();
			System.out.println("enter user details name and password");
			voter.authenticateUser(sc.next(), sc.next());
		}

	}

}
