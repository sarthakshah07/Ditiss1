package tester;

import java.sql.SQLException;
import java.util.Scanner;

import dao.CandidateImple;

public class TestIncrementVotes {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in)) {
			CandidateImple cm=new CandidateImple();
			cm.IncrementVotes(sc.next());
		} catch (SQLException e) {
		
			e.printStackTrace();
		}

	}

}
