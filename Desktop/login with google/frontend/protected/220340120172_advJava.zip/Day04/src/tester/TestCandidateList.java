package tester;

import java.sql.SQLException;

import dao.CandidateImple;

public class TestCandidateList {

	public static void main(String[] args) throws SQLException {
		CandidateImple cm=new CandidateImple();
		cm.getCandidateDetails();
		

	}

}
