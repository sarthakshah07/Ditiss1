package dao;

import java.sql.SQLException;

import pojos.Voter;

public interface IDaoVoter {
	Voter authenticateVoter(String name, String password) throws SQLException;

}
