package dao;

import static utils.DBUtils.getCn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.Voter;

public class DaoVoterImple implements IDaoVoter {
	// state
	private Connection cn;
	private PreparedStatement pst1;

	public  DaoVoterImple () throws SQLException {
		// open connection will be invoked once from init() of the servlet
		// get existing cn
		cn = getCn();
		// pst : auth
		pst1 = cn.prepareStatement("select * from voters where name=? and password=?");
		System.out.println("user dao created ....");
	}

	@Override
	public Voter authenticateVoter(String name, String password) throws SQLException {
		// set IN params
		pst1.setString(1, name);
		pst1.setString(2, password);
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next())
				return new Voter(rst.getInt(1), name, rst.getString(3), password, rst.getBoolean(5),rst.getString(6));
		}
		return null;
	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		System.out.println("user dao cleaned up");
	}
}
