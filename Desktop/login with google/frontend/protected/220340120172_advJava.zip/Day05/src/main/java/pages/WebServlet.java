package pages;

public @interface WebServlet {

}
