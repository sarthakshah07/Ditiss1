package beans;

import dao.CandidateDaoImpl;
import dao.VoterDaoImpl;

public class SubmitVoteBean {
	private int candidateId;
	private int voterId;
	private CandidateDaoImpl candiDao;
	private VoterDaoImpl voterDao;
	
	
	
	public VoterDaoImpl getVoterDao() {
		return voterDao;
	}
	public void setVoterDao(VoterDaoImpl voterDao) {
		this.voterDao = voterDao;
	}
	public CandidateDaoImpl getCandiDao() {
		return candiDao;
	}
	public void setCandiDao(CandidateDaoImpl candiDao) {
		this.candiDao = candiDao;
	}
	public int getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}
	public int getVoterId() {
		return voterId;
	}
	public void setVoterId(int voterId) {
		this.voterId = voterId;
	}
	
	public String castVote()
	{
		voterDao.updateStatus(voterId);
		candiDao.updateVoteCount(candidateId);
		return "status";
	}
}
