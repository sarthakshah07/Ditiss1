package listeners;

public @interface WebListener {

}
