import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dao.CandidateDaoImpl;
import dao.VoterDaoImpl;
import pojo.Voter;
import utils.HibernateUtils;

public class Tester {
	public static void main(String[] args) {
		
		VoterDaoImpl voterDao=new VoterDaoImpl();
		CandidateDaoImpl candiDao=new CandidateDaoImpl();
		try(SessionFactory sf=HibernateUtils.getSf())
		{
//			Session session= sf.getCurrentSession();
//			Transaction tx=session.beginTransaction();
//			System.out.println(voterDao.authenticate("rama@gmail.com","ram#123"));
//			System.out.println(voterDao.updateStatus(2));
//			candiDao.getAllCandidates().forEach(e->System.out.println(e));
			System.out.println(candiDao.getTopTwo());
//			tx.commit();
			
		}
	}
}
