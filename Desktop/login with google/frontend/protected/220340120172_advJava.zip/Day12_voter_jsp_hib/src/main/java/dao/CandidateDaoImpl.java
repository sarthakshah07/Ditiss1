package dao;

import static utils.HibernateUtils.getSf;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojo.Candidate;

public class CandidateDaoImpl {

	public List<Candidate> getAllCandidates()
	{
		List<Candidate> list=null;
		Session session=null;
		Transaction tx=null;
		
		
		try {
			session=getSf().getCurrentSession();
			tx=session.beginTransaction();
	
			list=session.createQuery("select c from Candidate c",Candidate.class)
					.getResultList();
			
			tx.commit();
		}
		catch (RuntimeException e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return list;
	}
	
	public int updateVoteCount(int id)
	{
		int res=-1;
		Session session=null;
		Transaction tx=null;
		
		
		try {
			session=getSf().getCurrentSession();
			tx=session.beginTransaction();
			
			Candidate candidate= session.get(Candidate.class, id);
			candidate.setVotes(candidate.getVotes()+1);
			res=candidate.getVotes();
			tx.commit();
		}
		catch (RuntimeException e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return res;
	}
	
	public List<Candidate> getTopTwo()
	{
		List<Candidate> list=null;
		
		Session session=null;
		Transaction tx=null;
		
		
		try {
			session=getSf().getCurrentSession();
			tx=session.beginTransaction();
			
			list= session
					.createQuery("select c from Candidate c",Candidate.class)
					.getResultStream()
					.sorted((s1,s2) -> ((Integer)s2.getVotes()).compareTo(s1.getVotes()))
					.limit(2)
					.collect(Collectors.toList());
					
			
			tx.commit();
		}
		catch (RuntimeException e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return list;
	
	}
	
//	public List<Candidate> getPartyStats()
//	{
//		List<Candidate> list=null;
//		
//		Session session=null;
//		Transaction tx=null;
//		
//		
//		try {
//			session=getSf().getCurrentSession();
//			tx=session.beginTransaction();
//			
//			list= session
//					.createQuery("select c from Candidate c group ",Candidate.class)
//					.getResultStream()
//					.sorted((s1,s2) -> ((Integer)s2.getVotes()).compareTo(s1.getVotes()))
//					.limit(2)
//					.collect(Collectors.toList());
//					
//			
//			tx.commit();
//		}
//		catch (RuntimeException e) {
//			if(tx!=null)
//				tx.rollback();
//			throw e;
//		}
//		
//		return list;
//	
//	}
	
}
