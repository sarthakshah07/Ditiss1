package dao;

import static utils.HibernateUtils.getSf;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojo.Voter;
public class VoterDaoImpl {

	public Voter authenticate(String email,String password)
	{
		Session session=null;
		Transaction tx=null;
		Voter voter=null;
		
		try {
			session=getSf().getCurrentSession();
			tx=session.beginTransaction();
			
			voter=session
					.createQuery("select v from Voter v where email= :emailVal",Voter.class)
					.setParameter("emailVal", email)
					.getSingleResult();
			
			if(voter.getPassword().equals(password))
			{
				return voter;
			}
			
			
			tx.commit();
		}
		catch (RuntimeException e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return voter;
	}
	
	public boolean updateStatus(int id)
	{
		boolean status=false;
		
		Session session=null;
		Transaction tx=null;
		
		
		try {
			session=getSf().getCurrentSession();
			tx=session.beginTransaction();
			
			Voter voter=session.get(Voter.class, id);
			voter.setStatus(true);		
			status=true;
			tx.commit();
		}
		catch (RuntimeException e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return status;
	}
	
}	
