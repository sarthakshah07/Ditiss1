package listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.hibernate.Hibernate;

import utils.HibernateUtils;

@WebListener
public class AppStartupListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		HibernateUtils.closeSf();
		System.out.println("Triggered Hibernate UnLoading!");
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		HibernateUtils.getSf();
		System.out.println("Triggered Hibernate loading!");
	}

	
	
}
