package beans;
import pojo.*;

import javax.persistence.NoResultException;

import dao.*;
public class UserAuthenticationBean {
	private String username;
	private String password;
	private Voter authenticaedVoter;
	private VoterDaoImpl voterDao;
	private CandidateDaoImpl candiDao;
	public UserAuthenticationBean() {
		voterDao=new VoterDaoImpl();
		candiDao=new CandidateDaoImpl();
	}

	public UserAuthenticationBean(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	public VoterDaoImpl getVoterDao() {
		return voterDao;
	}

	public void setVoterDao(VoterDaoImpl voterDao) {
		this.voterDao = voterDao;
	}

	public CandidateDaoImpl getCandiDao() {
		return candiDao;
	}

	public void setCandiDao(CandidateDaoImpl candiDao) {
		this.candiDao = candiDao;
	}

	public Voter getAuthenticaedVoter() {
		return authenticaedVoter;
	}

	public void setAuthenticaedVoter(Voter authenticaedVoter) {
		this.authenticaedVoter = authenticaedVoter;
	}

	@Override
	public String toString() {
		return "UserAuthenticationBean [username=" + username + ", password=" + password + "]";
	}
	
	public String authenticateUser()
	{
		try
		{
			authenticaedVoter=voterDao.authenticate(username, password);
		}
		catch(NoResultException e){
			authenticaedVoter=null;
		}
		
		if(authenticaedVoter!=null)
		{
			password=null;
			authenticaedVoter.setPassword(null);
			if(authenticaedVoter.getRole().toLowerCase().equals("voter"))
				return "voter_home";
			else
				return "admin_home";
				
		}
		return "login";
	}
	
	public String updateStatus()
	{
		String res="Casted Vote Successfully!";
		if(!authenticaedVoter.isStatus())
		{
			voterDao.updateStatus(authenticaedVoter.getId());
		}
		return res;
	}
	
	
}
