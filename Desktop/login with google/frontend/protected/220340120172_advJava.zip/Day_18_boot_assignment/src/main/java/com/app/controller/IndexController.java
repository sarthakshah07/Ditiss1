package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class IndexController {
	public IndexController() {
		System.out.println("In contr of IndexController");
	}
	
	@GetMapping("/")
	public String showIndex() {
		System.out.println("In show Index");
		return "/index";
	}
}
