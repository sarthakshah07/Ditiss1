package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.IDepartmentDao;
import com.app.dao.IEmployeeDao;

@Controller
@RequestMapping("/organization")
public class OrganizationController {
	@Autowired
	private IEmployeeDao empDao;
	@Autowired
	private IDepartmentDao deptDao;
	
	public OrganizationController() {
		System.out.println("In OrganizationController");
	}
	
	@GetMapping("/dept")
	
	public String showDepartments(Model map) {
		System.out.println("In showDepartments");
		map.addAttribute("dept_list",deptDao.getAllDepartments());
		return "/organization/dept";
	}
	
	@GetMapping("emplist")
	public String showAllEmployee(@RequestParam long deptId,Model map) {
		System.out.println("In showAllEmployee");
		map.addAttribute("emp_list", empDao.getAllEmployeeOfSpecificDepartment(deptId));
		return "/organization/emplist";
	}
}
