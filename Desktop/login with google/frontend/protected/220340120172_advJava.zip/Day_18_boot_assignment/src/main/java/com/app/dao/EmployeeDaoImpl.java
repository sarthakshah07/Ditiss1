package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Employee;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@Autowired
	private EntityManager manager;

	@Override
	public List<Employee> getAllEmployeeOfSpecificDepartment(long deptId) {
		String jpql="select e from Employee e join e.dept d where d.id=:id";
		return manager.createQuery(jpql, Employee.class)
				.setParameter("id",deptId)
				.getResultList();
	}

}
