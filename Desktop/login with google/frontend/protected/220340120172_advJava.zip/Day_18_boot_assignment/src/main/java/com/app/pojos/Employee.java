package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "emp_tbl")
public class Employee extends BaseEntity {
	@Column(length = 20)
	private String name;
	@Embedded
	private Address address;
	private double salary;
	@Column(name = "join_date")
	private LocalDate joinDate;

	@ManyToOne
	@JoinColumn(name = "dept_id", nullable = false)
	private Department dept;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Employee(String name, double salary, LocalDate joinDate) {
		super();
		this.name = name;
		this.salary = salary;
		this.joinDate = joinDate;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + ", joinDate=" + joinDate + "]";
	}

}
