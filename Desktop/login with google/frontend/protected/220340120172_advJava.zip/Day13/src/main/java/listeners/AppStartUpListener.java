package listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import utils.HibernateUtils;

@WebListener
public class AppStartUpListener implements ServletContextListener{
 
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("Loading Hibernate");
		HibernateUtils.getSf();
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("UnLoading Hibernate");
//		HibernateUtils.closeSf();
	}
}
