package dao;

import pojos.Topic;

public interface ITopicDao {
	/*
	 *  Add new topic User i/p : topic details
	 */
	String addNewTopic(Topic topic);
}
