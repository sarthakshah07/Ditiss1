package assignment;

import java.time.LocalDate;

import org.hibernate.SessionFactory;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import utils.HibernateUtils;

public class Launcher {

	public static void main(String[] args) {
		try(SessionFactory sf=HibernateUtils.getSf())
		{
			TutorialDaoImpl tutDao=new TutorialDaoImpl();
			
//			tutDao.getAllTitlesByAuthorAndAfterDate("abc", LocalDate.parse("1955-11-12"))
//			.forEach(e->System.out.println(e));;
			
//			tutDao.getAllTitlesIncludingKeyword("dh")
//			.forEach(e->System.out.println("-> "+e));
			
			TopicDaoImpl topDao=new TopicDaoImpl();
			topDao.getTopicsByAuthorName("abc").forEach(e->System.out.println("<-> "+e));
			
			
		}
	}
}
