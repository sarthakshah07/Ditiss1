package dao;

import static utils.HibernateUtils.getSf;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Address;
import pojos.User;
import utils.HibernateUtils;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User user) {
		// get session from SF
		Session session=getSf().getCurrentSession();
		//begin tx
		Transaction tx=session.beginTransaction();
		try {
			session.persist(user);
			tx.commit();
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return "New User registered with ID "+user.getId();
	}

	public List<Address> getCompleteUserDetials(long userId)
	{
		List<Address> list=null;
		Session session=null;
		Transaction tx=null;
		
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();

			String jpql="select a from Address a join fetch a.owner u";
			list=session.createQuery(jpql,Address.class)
					.getResultList();
			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return list;
	}
}
