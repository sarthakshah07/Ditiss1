package dao;

import pojos.User;

public interface IUserDao {
//register user
	String registerUser(User user);
}
