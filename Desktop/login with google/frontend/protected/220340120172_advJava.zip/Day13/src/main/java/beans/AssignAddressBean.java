package beans;

import java.util.List;

import dao.AddressDaoImpl;
import dao.UserDaoImpl;
import pojos.Address;
import pojos.User;

public class AssignAddressBean {

	private String adrLine1;
	private String adrLine2;

	private String city;

	private String state;

	private String country;

	private String zipCode;

	private int ownerId;
	private User owner;
	
	private UserDaoImpl userDao;
	private AddressDaoImpl adrDao;

	public AssignAddressBean() {
		userDao=new UserDaoImpl();
		adrDao=new AddressDaoImpl();
	}

	public String getAdrLine1() {
		return adrLine1;
	}

	public void setAdrLine1(String adrLine1) {
		this.adrLine1 = adrLine1;
	}

	public String getAdrLine2() {
		return adrLine2;
	}

	public void setAdrLine2(String adrLine2) {
		this.adrLine2 = adrLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "AssignAddressBean [adrLine1=" + adrLine1 + ", adrLine2=" + adrLine2 + ", city=" + city + ", state="
				+ state + ", country=" + country + ", zipCode=" + zipCode + ", ownerId=" + ownerId + ", owner=" + owner
				+ "]";
	}

	public String assignAddressByOwnerId() {
		
		return adrDao.assignUserAddress(ownerId, new Address(adrLine1, adrLine2, city, state, country, zipCode));
	}
	
	public List<Address> getCompleteDetails()
	{
		return userDao.getCompleteUserDetials(ownerId);
	}
}
