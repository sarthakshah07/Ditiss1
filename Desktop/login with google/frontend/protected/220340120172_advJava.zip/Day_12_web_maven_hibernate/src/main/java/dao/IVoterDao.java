package dao;

import pojo.Voter;

public interface IVoterDao {
	
//	Voter authenticateVoter(String name, String password);
//	boolean updateVoterStatus(int voterId);
	Voter getVoterDetails(String name, String password);
}
