package bean;

import dao.VoterDaoImpl;
import pojo.Voter;

public class VoterBean {
	private VoterDaoImpl voterDao;
	private String voterName;
	private String voterPassword;
	private String message;

	// default constructor
	public VoterBean() {
		voterDao = new VoterDaoImpl();
		System.out.println("Voter Bean Created");
	}

	public VoterDaoImpl getVoterDao() {
		return voterDao;
	}

	public void setVoterDao(VoterDaoImpl voterDao) {
		this.voterDao = voterDao;
	}

	public String getVoterName() {
		return voterName;
	}

	public void setVoterName(String voterName) {
		this.voterName = voterName;
	}

	public String getVoterPassword() {
		return voterPassword;
	}

	public void setVoterPassword(String voterPassword) {
		this.voterPassword = voterPassword;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String authenticateVoter() {
		Voter v = voterDao.getVoterDetails(voterName, voterPassword);
		if (v == null) {
			message = "Invalid Login Credentials!";
			return "login";
		}
		System.out.println(v);
		message = "Login Successful!";
		if (v.getVoterRole().equals("admin")) {
			return "result";
		} else {
			return "display";
		}
	}
}
