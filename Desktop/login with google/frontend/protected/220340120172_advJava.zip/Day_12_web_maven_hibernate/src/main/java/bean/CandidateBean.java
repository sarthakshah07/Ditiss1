package bean;

import java.util.List;
import dao.CandidateDaoImpl;
import pojo.Candidate;

public class CandidateBean {
	private CandidateDaoImpl candidateDao;
	private int id;

	// default constructor
	public CandidateBean() {
		candidateDao = new CandidateDaoImpl();
		System.out.println("Candidate Bean created");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CandidateDaoImpl getCandidateDao() {
		return candidateDao;
	}

	public void setCandidateDao(CandidateDaoImpl candidateDao) {
		this.candidateDao = candidateDao;
	}

	public List<Candidate> getAllCandidates() {
		return candidateDao.fetchAllCandidate();
	}

	public String incrementCandidateVotes() {
		return candidateDao.incrementVotes(id);
	}

	public List<String> topTwoCandidates() {
		return candidateDao.showTopTwoCandidate();
	}

	public List<Candidate> voteAnalysis() {
		return candidateDao.displayVoteAnalysis();
	}
}
