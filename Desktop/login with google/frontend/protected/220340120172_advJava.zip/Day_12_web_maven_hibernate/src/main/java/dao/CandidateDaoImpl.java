package dao;

import java.util.List;
import org.hibernate.*;
import pojo.Candidate;
import static utils.HibernateUtils.getSf;

public class CandidateDaoImpl implements ICandidateDao {

	@Override
	public List<Candidate> fetchAllCandidate() {
		List<Candidate> candidateList = null;
		String jpql = "select c from Candidate c";
		// get session from sf
		Session session = getSf().getCurrentSession();
		// begin transaction
		Transaction tx = session.beginTransaction();

		try {
			candidateList = session.createQuery(jpql, Candidate.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return candidateList;
	}

	@Override
	public String incrementVotes(int candidateId) {
		String message = "Vote increment status failed!!!";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();

		try {
			Candidate candidate = session.get(Candidate.class, candidateId);
			if (candidate != null) {
				candidate.setCandidateVote(candidate.getCandidateVote() + 1);
				message = "Vote incremented successfully";
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return message.toString();
	}

	@Override
	public List<String> showTopTwoCandidate() {
		List<String> candidateList = null;
		String jpql = "select c.candidateName from Candidate c order by c.candidateVote desc limit 2";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();

		try {
			candidateList = session.createQuery(jpql, String.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return candidateList;
	}

	@Override
	public List<Candidate> displayVoteAnalysis() {
		List<Candidate> voteList = null;
		String jpql = "select c.candidateParty, c.candidateVote from Candidate c order by c.candidateParty";
		
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		try {
			voteList = session.createQuery(jpql, Candidate.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if(tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return voteList;
	}

}
