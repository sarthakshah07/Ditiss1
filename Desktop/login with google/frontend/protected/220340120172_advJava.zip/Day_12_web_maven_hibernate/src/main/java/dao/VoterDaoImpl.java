package dao;

import pojo.Voter;
import static utils.HibernateUtils.getSf;
import org.hibernate.*;

public class VoterDaoImpl implements IVoterDao {

	@Override
	public Voter getVoterDetails(String name, String password) {
		Voter voter = null;
		String jpql = "select v from Voter v where v.voterName = :voter_name and v.voterPassword = :voter_pass";

		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();

		try {
			voter = session.createQuery(jpql, Voter.class).setParameter("voter_name", name).setParameter("voter_pass", password).getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return voter;
	}

}
