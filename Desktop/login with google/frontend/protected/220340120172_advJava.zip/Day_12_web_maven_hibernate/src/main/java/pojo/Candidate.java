package pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "candidates")
public class Candidate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer candidateId;
	@Column(name = "name", length = 20, unique = true)
	private String candidateName;
	@Column(name = "party", length = 20)
	private String candidateParty;
	@Column(name = "votes")
	private int candidateVote;

	public Candidate() {
		// TODO Auto-generated constructor stub
	}

	public Candidate(int candidateId, String candidateName, String candidateParty, int candidateVote) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.candidateParty = candidateParty;
		this.candidateVote = candidateVote;
	}

	public Candidate(String candidateName) {
		super();
		this.candidateName = candidateName;
	}

	public Candidate(String candidateParty, int candidateVote) {
		super();
		this.candidateParty = candidateParty;
		this.candidateVote = candidateVote;
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getCandidateParty() {
		return candidateParty;
	}

	public void setCandidateParty(String candidateParty) {
		this.candidateParty = candidateParty;
	}

	public int getCandidateVote() {
		return candidateVote;
	}

	public void setCandidateVote(int candidateVote) {
		this.candidateVote = candidateVote;
	}

	@Override
	public String toString() {
		return "Candidates [candidateId=" + candidateId + ", candidateName=" + candidateName + ", candidateParty="
				+ candidateParty + ", candidateVote=" + candidateVote + "]";
	}

}
