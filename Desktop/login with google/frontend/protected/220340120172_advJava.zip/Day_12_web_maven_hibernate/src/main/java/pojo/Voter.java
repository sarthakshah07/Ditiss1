package pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "voters")
public class Voter {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "name", length = 20, unique = true)
	private String voterName;
	@Column(name = "email", length = 20, unique = true)
	private String voterEmail;
	@Column(name = "password", length = 20)
	private String voterPassword;
	@Column(name = "status")
	private boolean voterStatus;
	@Column(name = "role", length = 20)
	private String voterRole;

	public Voter() {
		// TODO Auto-generated constructor stub
	}

	public Voter(int id, String voterName, String voterEmail, String voterPassword, boolean voterStatus,
			String voterRole) {
		super();
		this.id = id;
		this.voterName = voterName;
		this.voterEmail = voterEmail;
		this.voterPassword = voterPassword;
		this.voterStatus = voterStatus;
		this.voterRole = voterRole;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVoterName() {
		return voterName;
	}

	public void setVoterName(String voterName) {
		this.voterName = voterName;
	}

	public String getVoterEmail() {
		return voterEmail;
	}

	public void setVoterEmail(String voterEmail) {
		this.voterEmail = voterEmail;
	}

	public String getVoterPassword() {
		return voterPassword;
	}

	public void setVoterPassword(String voterPassword) {
		this.voterPassword = voterPassword;
	}

	public boolean isVoterStatus() {
		return voterStatus;
	}

	public void setVoterStatus(boolean voterStatus) {
		this.voterStatus = voterStatus;
	}

	public String getVoterRole() {
		return voterRole;
	}

	public void setVoterRole(String voterRole) {
		this.voterRole = voterRole;
	}

	@Override
	public String toString() {
		return "Voters [id=" + id + ", voterName=" + voterName + ", voterEmail=" + voterEmail + ", voterStatus="
				+ voterStatus + ", voterRole=" + voterRole + "]";
	}

}
