package dao;

import java.util.List;
import pojo.Candidate;

public interface ICandidateDao {

	List<Candidate> fetchAllCandidate();

	String incrementVotes(int candidateId);

	List<String> showTopTwoCandidate();

	List<Candidate> displayVoteAnalysis();

}
