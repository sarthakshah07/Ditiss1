package com.app.pojos;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "emp_table")
public class Employee extends BaseEntity {
	@Column(name = "emp_name")
	private String empName;
	@Column(name = "emp_salary")
	private double empSalary;
	@Column(name = "emp_address")
	private String empAddress;
	@Column(name = "join_date")
	private Date joinDate;
	// unidirectional many to one relationship between Employee *----> Department
	@ManyToOne
//	@JoinTable(name = "emp_dept", joinColumns = @JoinColumn(name = "emp_id"), inverseJoinColumns = @JoinColumn(name = "dept_id"))
	@JoinColumn(name = "emp_dept", nullable = false)
	private Department department;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(String empName, double empSalary, String empAddress, Date joinDate) {
		super();
		this.empName = empName;
		this.empSalary = empSalary;
		this.empAddress = empAddress;
		this.joinDate = joinDate;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee ID: " + getId() + "[Name: " + empName + ", Salary: " + empSalary + ", Address: " + empAddress
				+ ", Join Date: " + joinDate + "]";
	}

}
