package com.app.pojos;

import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name = "dept_table")
public class Department extends BaseEntity {
	@Enumerated(EnumType.STRING)
	@Column(name = "dept_name", length = 20)
	private DepartmentName deptName;
	@Column(name = "dept_location", length = 20)
	private String deptLocation;
	
	public Department() {
		System.out.println("in dept. constructot " + getClass());
	}

	public Department(DepartmentName deptName) {
		super();
		this.deptName = deptName;
	}

	public DepartmentName getDeptName() {
		return deptName;
	}

	public void setDeptName(DepartmentName deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		return deptLocation;
	}

	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	@Override
	public int hashCode() {
		return Objects.hash(deptName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		return deptName == other.deptName;
	}

	@Override
	public String toString() {
		return "Department ID: " + getId() + " [Department Name: " + deptName + " Location: " + deptLocation + "]";
	}

}
