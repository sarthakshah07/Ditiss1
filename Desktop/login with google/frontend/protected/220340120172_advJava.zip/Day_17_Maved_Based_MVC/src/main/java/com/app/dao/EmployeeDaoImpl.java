package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.app.pojos.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public List<Employee> getAllEmpByDeptName(String deptName) {
		String jpql = "select e from Emoloyee e join e.empDepartment d where d.deptName = :deptName";
		
		return sf.getCurrentSession().createQuery(jpql, Employee.class).setParameter("deptName", deptName)
				.getResultList();
	}

}
