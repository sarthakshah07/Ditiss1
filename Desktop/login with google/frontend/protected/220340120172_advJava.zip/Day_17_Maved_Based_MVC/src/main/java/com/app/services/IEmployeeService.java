package com.app.services;

import java.util.List;
import com.app.pojos.Employee;

public interface IEmployeeService {
	// method to get all employees using deptname
	List<Employee> getAllEmpByDeptName(String deptName);
}
