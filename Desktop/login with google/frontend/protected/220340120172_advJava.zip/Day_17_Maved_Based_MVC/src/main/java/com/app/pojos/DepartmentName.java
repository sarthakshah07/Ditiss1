package com.app.pojos;

public enum DepartmentName {
	RND, HR, ADMIN, FINANCE, MARKET
}
