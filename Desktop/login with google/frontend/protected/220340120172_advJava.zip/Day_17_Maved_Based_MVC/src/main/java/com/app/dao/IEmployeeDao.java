package com.app.dao;

import java.util.List;
import com.app.pojos.Employee;

public interface IEmployeeDao {
	// method to get all employees using deptname
		List<Employee> getAllEmpByDeptName(String deptName);
}
