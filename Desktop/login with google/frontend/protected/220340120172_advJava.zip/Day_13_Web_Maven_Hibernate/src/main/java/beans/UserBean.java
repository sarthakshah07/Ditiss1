package beans;

import dao.UserDaoImpl;
import pojos.User;

public class UserBean {
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	// dependency
	private UserDaoImpl userDao;
	private User registeredUser;
//	private String message;
	
	public UserBean() {
		System.out.println("User Bean created");
		userDao = new UserDaoImpl();
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	public User getRegisteredUser() {
		return registeredUser;
	}

	public void setRegisteredUser(User registeredUser) {
		this.registeredUser = registeredUser;
	}
//	
//	public String getMessage() {
//		return message;
//	}

	public String registerNewUser() {
		User newUser = new User(firstName, lastName, email, password);
//		registeredUser = userDao.registerUser(newUser);
		return userDao.registerUser(newUser);
	}
}
