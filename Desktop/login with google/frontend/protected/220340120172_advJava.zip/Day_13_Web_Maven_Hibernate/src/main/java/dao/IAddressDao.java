package dao;

import pojos.Address;

public interface IAddressDao {
	/*
	 * Assign User details
	 * User i/p user id, address_details
	 */
	String assignUserAddress(long userId, Address address);
}
