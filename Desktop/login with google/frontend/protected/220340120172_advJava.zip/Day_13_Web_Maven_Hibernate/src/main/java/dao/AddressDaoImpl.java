package dao;

import static utils.HibernateUtils.getSf;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Address;
import pojos.User;

public class AddressDaoImpl implements IAddressDao {

	@Override
	public String assignUserAddress(long userId, Address address) {
		String message = "Assigning address failed!!!";
		// get session from sf
		Session session = getSf().getCurrentSession();
		// begin transaction
		Transaction tx = session.beginTransaction();
		try {
			// 1. get user details from user id
			User user = session.get(User.class, userId);
			
			if(user != null) {
				// establish unidirectional link Address ----> User
				address.setOwner(user);
				session.persist(address);
				message = "Assigned address successfuly to owner: " + user.getFirstName();
				tx.commit();
			}
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return message;
	}

}
