package dao;

import org.hibernate.*;
import static utils.HibernateUtils.getSf;

import pojos.User;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User newUser) {
		// get session from sf
		Session session = getSf().getCurrentSession();
		// begin transaction
		Transaction tx = session.beginTransaction();
		try {
			session.persist(newUser);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return "New User: " + newUser.getEmail() + " registered with ID: " + newUser.getId();
	}

}
