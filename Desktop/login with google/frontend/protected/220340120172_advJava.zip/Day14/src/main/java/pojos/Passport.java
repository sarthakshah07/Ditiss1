package pojos;

import java.time.LocalDate;

import javax.persistence.Embeddable;

@Embeddable
public class Passport {

	private String passportNumber;
	private LocalDate createDate;
	private String country;
	
	
	
	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public Passport() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Passport(String passportNumber, LocalDate createDate) {
		super();
		this.passportNumber = passportNumber;
		this.createDate = createDate;
	}



	public String getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	public LocalDate getCreateDate() {
		return createDate;
	}
	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}
	
	
}
