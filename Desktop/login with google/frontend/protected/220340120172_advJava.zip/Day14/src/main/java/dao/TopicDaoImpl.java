package dao;

import static utils.HibernateUtils.getSf;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Topic;
import utils.HibernateUtils;

public class TopicDaoImpl implements ITopicDao {

	@Override
	public String addNewTopic(Topic topic) {
		// get session from SF
		Session session = getSf().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(topic);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return "New Topic Added with ID " + topic.getId();
	}

	public Set<Topic> getTopicsByAuthorName(String name)
	{
		Set<Topic> list=null;
		Session session=null;
		Transaction tx= null;;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();
			String jpql="select tp from Tutorial t join t.topic tp join t.author a where a.firstName=:nm";
			
			list=session.createQuery(jpql,Topic.class)
					.setParameter("nm", name)
					.getResultStream()
					.collect(Collectors.toSet());
//					.getResultList();
			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return list;
	}
	
}
