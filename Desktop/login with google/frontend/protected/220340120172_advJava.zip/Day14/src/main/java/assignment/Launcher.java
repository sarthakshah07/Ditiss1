package assignment;

import java.time.LocalDate;
import java.util.Arrays;

import org.hibernate.SessionFactory;

import dao.RoleDao;
import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.Passport;
import pojos.UserRole;
import utils.HibernateUtils;

public class Launcher {

	public static void main(String[] args) {
		try(SessionFactory sf=HibernateUtils.getSf())
		{
			RoleDao roleDao=new RoleDao();
			UserDaoImpl userDao=new UserDaoImpl();
			TutorialDaoImpl tutDao=new TutorialDaoImpl();
//			Arrays.asList(UserRole.values()).forEach(e->System.out.println(roleDao.insertRole(e)));
//			System.out.println(userDao.addNewRolesToUser((long)1,(long)1,(long)2));
//			tutDao.addAComment((long)1, (long)1, "yarr hhshs bhai are");
//			tutDao.deleteById((long)1);
//			userDao.assignPassport((long)1,new Passport("hshshhshsh", LocalDate.now()));
			userDao.getAllByPassportCountry("IN").forEach(e->System.out.println(e));
		}
	}
}
