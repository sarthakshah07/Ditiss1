package dao;

import static utils.HibernateUtils.getSf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Address;
import pojos.Passport;
import pojos.Role;
import pojos.User;
import utils.HibernateUtils;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User user) {
		// get session from SF
		Session session=getSf().getCurrentSession();
		//begin tx
		Transaction tx=session.beginTransaction();
		try {
			session.persist(user);
			tx.commit();
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return "New User registered with ID "+user.getId();
	}

	public List<Address> getCompleteUserDetials(long userId)
	{
		List<Address> list=null;
		Session session=null;
		Transaction tx=null;
		
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();

			String jpql="select a from Address a join fetch a.owner u";
			list=session.createQuery(jpql,Address.class)
					.getResultList();
			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return list;
	}
	
	public User addNewRolesToUser(Long userid,Long...roleId)
	{
		Set<Role> roles=getRolesById(roleId);
//		System.out.println(roles);
		User user;
		Session session=null;
		Transaction tx=null;
		Long id=null;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();	
			user=session.get(User.class, userid);
			roles.forEach(e-> user.addNewRole(e));
			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
//		return id;
		return user;
	}

	private Set<Role> getRolesById(Long[] roleId) {
		Set<Role> roles=new HashSet<>();
		Session session;
		Transaction tx=null;
		Long id=null;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();	

			Arrays.asList(roleId).forEach(
					e -> roles.add(session.get(Role.class, e))
					);
			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return roles;
	}
	public void assignPassport(Long userId,Passport passport)
	{

	
		Session session;
		Transaction tx=null;
		Long id=null;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();	

			session.get(User.class, userId).setPassport(passport);;			
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		
	
	}
	
	public List<User> getAllByPassportCountry(String country)
	{
		List<User> list;

		Session session;
		Transaction tx=null;
		Long id=null;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();	

			String jpql="select u from User u where u.passport.country= :val";
					list=session.createQuery(jpql,User.class)
					.setParameter("val", country)
					.getResultList();
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		
	
	
		
		return list;
		
	}
	
}
