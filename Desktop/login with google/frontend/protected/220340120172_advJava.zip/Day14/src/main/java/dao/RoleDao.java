package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Role;
import pojos.UserRole;
import utils.HibernateUtils;

public class RoleDao {

	public Long insertRole(UserRole userRole)
	{
		Role role=new Role();
		role.setRole(userRole);
		Session session=null;
		Transaction tx=null;
		Long id=null;
		try {
			session=HibernateUtils.getSf().getCurrentSession();
			tx=session.beginTransaction();	

			session.persist(role);
			id=role.getId();
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return id;
	}
	
}
