package utils;
import java.sql.*;

public class DBUtils {
	private static Connection cn;
	public static Connection  openConnection() throws SQLException
	{
		
		String url = "jdbc:mysql://localhost:3306/dac22?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true";
		
		return cn=DriverManager.getConnection(url,"root","123456");
	}
	
	//add static method to return db cn to caller
	public static Connection getCn() {
		return cn;
	}
	
	
	//add static close
	public static void closeConnection() throws SQLException {
		if(cn !=null)
			cn.close();
	}
}
