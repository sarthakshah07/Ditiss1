package dao;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import pojos.Employee;

public interface iEmpDao {
	//add method declaration
	List <Employee> getEmpDetails(String deptName, Date date) throws SQLException; 
	
}
