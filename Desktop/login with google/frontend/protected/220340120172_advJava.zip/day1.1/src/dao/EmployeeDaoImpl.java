package dao;

import java.sql.*;
import java.util.List;
import pojos.Employee;
import static utils.DBUtils.*;




public class EmployeeDaoImpl implements iEmpDao {

	private Connection cn;
	private PreparedStatement pst1;
	
	public EmployeeDaoImpl() throws SQLException {
		cn=openConnection();
		
		pst1=cn.prepareStatement("select *from my_emp where deptid=? and join_date>?");
		System.out.println("emp dao created......");
	}
	
	

	@Override
	public List<Employee> getEmpDetails(String deptName, Date date) throws SQLException {
		List <Employee>emps=new AarryList<>();
		
		pst1.setString(1, deptName);
		pst1.setDate(2, date);
		
		try(ResultSet rst = pst1.executeQuery())
		{
			while(rst.next())
		}
		return null;
	}
	public void cleanUp() throws SQLException {
		if(pst1 != null)
			pst1.close();
		closeConnection();
		System.out.println("emp dao cleaned up");
		
	}
}
