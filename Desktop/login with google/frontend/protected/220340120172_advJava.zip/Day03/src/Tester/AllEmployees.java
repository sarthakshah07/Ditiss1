package Tester;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import static Utils.DBCon.*;

public class AllEmployees {
	public static void main(String[] args) {
		try(Connection cn = openConnection()){
		//The object of statement is responsible to execute queries with the database.
			Statement stmt = cn.createStatement(); //create a statement
			//executeQuery: Used to execute query in the database  
			//ResultSet: returns the object of ResultSet that can be used to get all the records of a table.
			ResultSet rst = stmt.executeQuery("select * from my_emp");
			
			System.out.println("All Employees");
			while(rst.next()) {
				System.out.printf("[ Emp Id: %d, Name: %s, Address: %s, Salary: %.2f, Dept ID: %s, Joined on: %s ] %n", rst.getInt(1),
						rst.getString(2), rst.getString(3), rst.getDouble(4), rst.getString(5), rst.getDate(6));			
			}
			System.out.println("*******************\n");
			System.out.println("All employees from 2018-01-01 to 2019-01-01");
			
			ResultSet rst1 = stmt.executeQuery("select * from my_emp where salary > 15000 and join_date > '2019-01-01';\r\n"
					+ "");
			//ResultSet rst1 = stmt.executeQuery("select * from my_emp where join_date BETWEEN '2018-01-01' AND '2020-12-31' having salary > 15000");
			
			while(rst1.next()) {
				System.out.printf("[ Emp Id: %d, Name: %s, Address: %s, Salary: %.2f, Dept ID: %s, Joined on: %s ] %n", rst1.getInt(1),
						rst1.getString(2), rst1.getString(3), rst1.getDouble(4), rst1.getString(5), rst1.getDate(6));			
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
