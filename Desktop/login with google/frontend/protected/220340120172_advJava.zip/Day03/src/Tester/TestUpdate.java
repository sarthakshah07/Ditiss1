package Tester;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import static Utils.DBCon.*;

public class TestUpdate {

	public static void main(String[] args) {
		try (Connection conn = openConnection()){
				Statement st = conn.createStatement();
				ResultSet rst = st.executeQuery("select * from my_emp where empid = 3"); 
			
				System.out.println("EMP ID 3 Salary before updation::");
			while (rst.next())
				System.out.printf("[ Emp Id: %d, Name: %s, Address: %s, Salary: %.2f, Dept: %s, Joined on: %s ]%n", rst.getInt(1),
						rst.getString(2), rst.getString(3), rst.getDouble(4), rst.getString(5), rst.getDate(6));
			
		
			st.executeUpdate("update my_emp set salary = salary + 5000 where empid=3"); 
			System.out.println("Salary updated\n***********************************");			
					
			System.out.println("EMP ID 3 salary after updation::");
			ResultSet rst2 = st.executeQuery("select * from my_emp where empid = 3"); 
			
			while (rst2.next())
				System.out.printf("[ Emp Id: %d, Name: %s, Address: %s, Salary: %.2f, Dept: %s, Joined on: %s ]%n", rst2.getInt(1),
						rst2.getString(2), rst2.getString(3), rst2.getDouble(4), rst2.getString(5), rst2.getDate(6));
		}		
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
