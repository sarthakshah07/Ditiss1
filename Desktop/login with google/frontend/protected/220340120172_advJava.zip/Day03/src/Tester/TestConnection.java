package Tester;

import java.sql.Connection;
import static Utils.DBCon.*;

public class TestConnection {

	public static void main(String[] args) {
		try(Connection cn = openConnection()){
			System.out.println("Connected...");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
