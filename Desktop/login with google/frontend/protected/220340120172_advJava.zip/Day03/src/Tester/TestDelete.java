package Tester;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import static Utils.DBCon.*;

public class TestDelete {

	public static void main(String[] args) {
		try (Connection conn = openConnection()){
				Statement st = conn.createStatement();
				st.executeUpdate("delete from my_emp where empid = 6"); 
			
			ResultSet rst2 = st.executeQuery("select * from my_emp"); 
			
			while (rst2.next())
				System.out.printf("[ Emp Id: %d, Name: %s, Address: %s, Salary: %.2f, Dept: %s, Joined on: %s ]%n", rst2.getInt(1),
						rst2.getString(2), rst2.getString(3), rst2.getDouble(4), rst2.getString(5), rst2.getDate(6));
		}		
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}