package Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBCon {
	public static Connection cn;
	
	public static Connection openConnection() throws SQLException{
		String url = "jdbc:mysql://localhost:3306/dac22?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true";
		String userName = "root";
		String password = "root";
		
			//Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection(url, userName, password);
			//DriverManager class :  The DriverManager class acts as an interface between users and 
			// drivers. It keeps track of the drivers that are available and handles establishing a 
			// connection between a database and the appropriate driver. It contains all the 
			// appropriate methods to register and deregister the database driver class and to 
			// create a connection between a Java application and the database. 
			// The DriverManager class maintains a list of Driver classes that have registered 
			// themselves by calling the method DriverManager.registerDriver(). 
			// Note that before interacting with a Database, it is a mandatory process to register 
			// the driver; otherwise, an exception is thrown.
			
			return cn;
	}
	
	public static Connection getConnection() {
		return cn;	
	}
	
	public static void closeConnection() throws SQLException{
		if(cn != null) {
			cn.close();
		}
	}
	}
