package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Candidate;

public interface ICandidateDao {

	public List<Candidate> fetchAllCandidates() throws SQLException;

	public String incrementVotes(int candidateId)throws SQLException;
}
