package dao;

import java.sql.*;

import pojos.Voter;

import static utils.DBUtils.*;

public class VoterDaoImpl implements IVoterDao {

	// state
	Connection cn;
	PreparedStatement pst1, pst2;

	public VoterDaoImpl() throws SQLException {
		cn = openConnection();
		pst1 = cn.prepareStatement("select * from voters where name=? and password=?");
		pst2 = cn.prepareStatement("Update Voters set status=true where id=?");
		System.out.println("Dao Created ");

	}

	@Override
	public Voter authenticateVoter(String name, String password) throws SQLException {
		Voter v1 = new Voter();
		pst1.setString(1, name);
		pst1.setString(2, password);
		ResultSet rst = pst1.executeQuery();
		if (rst.next()) {
			v1 = new Voter(rst.getInt(1), name, rst.getString(3), rst.getString(4), rst.getBoolean(5),
					rst.getString(6));
			return v1;
		}
		return null;

	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		if (cn != null)
			cn.close();

	}

	@Override
	public String updateVotingStatus(int voterId) throws SQLException {
		pst2.setInt(1, voterId);
		int p = pst2.executeUpdate();
		if (p == 1) {
			return "Status changed Successfully";
		} else
			return "Wrong input";
	}
}
