package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojos.Candidate;

import static utils.DBUtils.*;

public class CandidateDaoImpl implements ICandidateDao {
	private Connection cn;
	private PreparedStatement pst1, pst2;

	public CandidateDaoImpl() throws SQLException {
		cn = openConnection();
		pst1 = cn.prepareStatement("Update candidates set votes=votes+1 where id=?");
		pst2 = cn.prepareStatement("select * from candidates");
	}

	@Override
	public String incrementVotes(int id) throws SQLException {
		pst1.setInt(1, id);
		int p = pst1.executeUpdate();
		if (p != 0) {
			return "Count incremented Successfully";
		} else
			return "Wrong Output";
	}

	@Override
	public List<Candidate> fetchAllCandidates() throws SQLException {
		List<Candidate> list1 = new ArrayList<Candidate>();
		try (ResultSet rst = pst2.executeQuery()) {
			while (rst.next()) {
				list1.add(new Candidate(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getInt(4)));
			}
		}
		return list1;
	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		// close db conn
		closeConnection();
		System.out.println("emp dao cleaned up !");
	}

}
