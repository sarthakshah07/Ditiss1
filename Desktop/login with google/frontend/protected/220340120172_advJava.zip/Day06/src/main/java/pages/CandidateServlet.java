package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CandidateDaoImpl;
import pojos.Candidate;
import pojos.Voter;

/**
 * Servlet implementation class CandidateServlet
 */
@WebServlet("/candidate")
public class CandidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h5>In Candidates Pages</h5>");
			HttpSession hs = request.getSession();
			System.out.println("Candiadte Servlet : is session new  : " + hs.isNew());
			System.out.println("Session Id : " + hs.getId());
			Voter validatedVoter = (Voter) hs.getAttribute("clnt_details");

			if (validatedVoter != null) {
				CandidateDaoImpl candidateDao = (CandidateDaoImpl) hs.getAttribute("candidate_dao");
				pw.print("<h5>Your Details : " + validatedVoter + "</h5>");
				List<Candidate> candidates = candidateDao.fetchAllCandidates();
				pw.print("<form action='status'>");
				for (Candidate c : candidates)
					pw.print("<h5><input type='radio' name='cid' value='" + c.getId() + "'/>" + c.getName()
							+ " <label>  Party=" + c.getParty() + "</label>" + "</h5>");
				pw.print("<h5><input type='submit' value='choose a candidate'/></h5>");
				pw.print("</form>");

			} else
				pw.print("<h5> No cookies !!!!!!!!!! NO Session Tracking!!!!");
		} catch (Exception e) {
			throw new ServletException("Err in de-get of " + getClass(), e);
		}

	}

}
