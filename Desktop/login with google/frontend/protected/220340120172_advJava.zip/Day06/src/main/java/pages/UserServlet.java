package pages;

import static utils.DBUtils.closeConnection;
import static utils.DBUtils.openConnection;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CandidateDaoImpl;
import dao.VoterDaoImpl;
import pojos.Voter;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet(value = "/validate", loadOnStartup = 3)
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VoterDaoImpl vDao;
	CandidateDaoImpl cDao;

	/**
	 * @see Servlet#init()
	 */
	public void init() throws ServletException {
		System.out.println("In init of " + getClass());
		try {
			openConnection();
			vDao = new VoterDaoImpl();
			cDao = new CandidateDaoImpl();
			System.out.println("In init of " + getClass());
		} catch (Exception e) {
			throw new ServletException("err in init block of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {

		try {
			System.out.println("In destroy of" + getClass());
			vDao.cleanUp();
			cDao.cleanUp();
			closeConnection();

		} catch (Exception e) {
			throw new RuntimeException("Error in destroy block of " + getClass(), e);

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			String name = request.getParameter("nm");
			String pass = request.getParameter("pass");
			Voter authenticatedVoter = vDao.authenticateVoter(name, pass);

			if (authenticatedVoter == null)
				pw.print("<h5>Invalid Login, please <a href='login.html'>Retry</a></h5>");
			else {
				HttpSession session = request.getSession();
				System.out.println("User servlet : is session new " + session.isNew());
				System.out.println("Session Id : " + session.getId());
				session.setAttribute("clnt_details", authenticatedVoter);
				session.setAttribute("voter_dao", vDao);
				session.setAttribute("candidate_dao", cDao);

				if (authenticatedVoter.getRole().equals("voter")) {
					if (authenticatedVoter.isStatus())
						response.sendRedirect("status");
					else
						response.sendRedirect("candidate");
				} else {
					response.sendRedirect("admin");
				}
			}
		} catch (Exception e) {
			throw new ServletException("Err in do-post " + getClass(), e);
		}

	}

}
