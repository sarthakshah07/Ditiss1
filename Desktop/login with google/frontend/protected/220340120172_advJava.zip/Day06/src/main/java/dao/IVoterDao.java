package dao;

import java.sql.SQLException;

import pojos.Voter;

public interface IVoterDao {

	public Voter authenticateVoter(String name, String password) throws SQLException;

	public String updateVotingStatus(int voterId) throws SQLException;
}
