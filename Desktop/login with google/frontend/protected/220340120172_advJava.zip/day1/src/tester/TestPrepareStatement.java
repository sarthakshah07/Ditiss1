package tester;
import java.sql.*;
import java.util.Scanner;
import static utils.DBUtils.openConnection;

public class TestPrepareStatement {

	public static void main(String[] args, String sql) {
		String sql1 = "select empid, name,salary,join_date from my_emp where deptd=? and join_date between ? and ?";
		try(Connection cn=openConnection();
			Scanner sc = new Scanner(System.in);
			PreparedStatement pst = cn.prepareStatement(sql1);
				//ResultSet rst = pst.executeQuery();
			)
		{
			System.out.println("ENTER DEPT ID , BEGIN DATE N END DATE");
			pst.setString(1, sc.next());
			pst.setDate(2, Date.valueOf(sc.next())); // begin date
			pst.setDate(3, Date.valueOf(sc.next())); // end date
			
			try(ResultSet rst=pst.executeQuery())
			{
				while(rst.next())
					System.out.printf("emp id %d name %s  salary %.2f  joined on %s%n",
							rst.getString(2),rst.getDouble(3),rst.getDate(4));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
