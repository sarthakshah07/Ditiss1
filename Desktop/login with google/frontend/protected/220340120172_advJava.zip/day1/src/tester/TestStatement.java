package tester;
import static utils.DBUtils.*;
import java.sql.*;

public class TestStatement {

	public static void main(String[] args) {
		try (Connection conn = openConnection();
				Statement st =conn.createStatement();
				ResultSet rst=st.executeQuery("select *from my_emp")
					)
		{
			//ystem.out.println("db conn establishment"+ conn);
			while(rst.next())
				System.out.printf("emp id %d name %s address %s salary %.2f dept %s joined on %s%n",
						rst.getInt(1),rst.getString(2),rst.getString(3),rst.getDouble(4),rst.getString(5),rst.getDate(6));
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
 